var nm__bus__wrapper__zynq__7000_8c =
[
    [ "NM_BUS_MAX_TRX_SZ", "nm__bus__wrapper__zynq__7000_8c.html#afbc973888cb214292ecd9094a69adf68", null ],
    [ "nm_bus_deinit", "nm__bus__wrapper__zynq__7000_8c.html#a577ad43e9d464f7309b5ffa75f4ae15a", null ],
    [ "nm_bus_init", "nm__bus__wrapper__zynq__7000_8c.html#a70bb25346f06ae807f5588fa0a536377", null ],
    [ "nm_bus_ioctl", "nm__bus__wrapper__zynq__7000_8c.html#aa98500dc13748397906e03440fb3892a", null ],
    [ "nm_bus_reinit", "nm__bus__wrapper__zynq__7000_8c.html#a65ee1293ab35f36aa7789f627f278fb5", null ],
    [ "nm_spi_rw", "nm__bus__wrapper__zynq__7000_8c.html#a5bff9c868966ce5b9f70409ac6c4eb2e", null ],
    [ "egstrNmBusCapabilities", "nm__bus__wrapper__zynq__7000_8c.html#ae7dfa29166b4111ca6c3e3bab953eb79", null ]
];