var nmdrv_8h =
[
    [ "tstrM2mRev", "structtstr_m2m_rev.html", "structtstr_m2m_rev" ],
    [ "nm_cpu_start", "nmdrv_8h.html#a449a0169a9efa7c147a37b1302d662fa", null ],
    [ "nm_drv_deinit", "nmdrv_8h.html#a444c8058e44c2381fcceac93a5f53a3c", null ],
    [ "nm_drv_init", "nmdrv_8h.html#a09c6ec4d7dedf7615abfab662222a243", null ],
    [ "nm_drv_init_download_mode", "nmdrv_8h.html#adbeaef467445b78a53f6ea53b4e6eae9", null ],
    [ "nm_drv_init_hold", "nmdrv_8h.html#ae7c9c8195ef624e9a0140e176b141566", null ],
    [ "nm_drv_init_start", "nmdrv_8h.html#a251e8bf1913f13cc0422ac5a2d84f241", null ],
    [ "nm_get_firmware_full_info", "nmdrv_8h.html#a5af9ae69808bb521b6d0837f06831aa0", null ],
    [ "nm_get_hif_info", "nmdrv_8h.html#a4d44960a30ee8ebe2ffd23b444faee2a", null ],
    [ "nm_get_ota_firmware_info", "nmdrv_8h.html#a54f1a7f936a2c718fff68618d8504c90", null ]
];