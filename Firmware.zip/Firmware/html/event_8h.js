var event_8h =
[
    [ "str_watched_event", "structstr__watched__event.html", "structstr__watched__event" ],
    [ "event_init", "event_8h.html#a703aee6d18b09a8b0e7fa762e6024594", null ],
    [ "event_post", "event_8h.html#aaa292d94b56982e1bbf2584e1444ca94", null ],
    [ "special_events_handler", "event_8h.html#a02587a5d6716dd9ed4aa90caf2293fa6", null ],
    [ "watched_event", "event_8h.html#ae30df1d0463a0f7c3885f90d6799fd55", null ]
];