var gattm__task_8c =
[
    [ "gattm_add_attribute_req_handler", "gattm__task_8c.html#a7d2caab8689ee9e82ee3126719bfc3f0", null ],
    [ "gattm_add_svc_req_handler", "gattm__task_8c.html#a792c4ac41708410cbcfc2f6998adc0ab", null ],
    [ "gattm_att_get_value_req_handler", "gattm__task_8c.html#a903cc1e3925489c5b4e5d7011b67992a", null ],
    [ "gattm_att_set_value_req_handler", "gattm__task_8c.html#a7bba37833776cc11c8780187a4f714f1", null ]
];