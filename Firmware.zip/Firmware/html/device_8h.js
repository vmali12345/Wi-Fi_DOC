var device_8h =
[
    [ "device_info", "structdevice__info.html", "structdevice__info" ],
    [ "at_ble_dev_role", "device_8h.html#a1bc4bc728daac374f82a1c980ee929f5", [
      [ "ROLE_MASTER", "device_8h.html#a1bc4bc728daac374f82a1c980ee929f5a47f287004d68c97c3589027d98225676", null ],
      [ "ROLE_SLAVE", "device_8h.html#a1bc4bc728daac374f82a1c980ee929f5a6cff0abbfa0fc9286a1d13b0ffd76cba", null ],
      [ "ROLE_END", "device_8h.html#a1bc4bc728daac374f82a1c980ee929f5a54cbe6d25cfd1585ebdd58c916e08c32", null ]
    ] ],
    [ "device", "device_8h.html#a1491a038afa030e49235ce9e49fa1595", null ]
];