var group__gatt_server =
[
    [ "at_ble_characteristic_value_get", "group__gatt-server.html#gaf7bfc71457cef3fde5c4e8721d6f0a5d", null ],
    [ "at_ble_characteristic_value_set", "group__gatt-server.html#ga505012ec9659b6c8a933611af55773b0", null ],
    [ "at_ble_indication_send", "group__gatt-server.html#ga53f16fb39e573e040d4b93571dfe97bb", null ],
    [ "at_ble_notification_send", "group__gatt-server.html#ga5c380b2c2344c8812dbf14a23a4ac1dc", null ],
    [ "at_ble_primary_service_define", "group__gatt-server.html#ga2bb39c52828d081737f5c4b65d68208d", null ],
    [ "at_ble_read_authorize_reply", "group__gatt-server.html#gac116eb742a635b09af653e047d444b8a", null ],
    [ "at_ble_secondary_service_define", "group__gatt-server.html#ga1451c0b1df4c345594ee175e7c3f382a", null ],
    [ "at_ble_service_changed_notification_send", "group__gatt-server.html#ga4211fd638d577472e2445be8000ea966", null ],
    [ "at_ble_write_authorize_reply", "group__gatt-server.html#ga99afb1074db53ac7dfd77bd4cb3fe313", null ]
];