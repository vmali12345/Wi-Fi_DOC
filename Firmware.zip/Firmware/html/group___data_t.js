var group___data_t =
[
    [ "Functions", "group___b_s_p_a_p_i.html", "group___b_s_p_a_p_i" ],
    [ "sint16", "group___data_t.html#ga74df79fde3c518e55b29ce6360a9c76e", null ],
    [ "sint32", "group___data_t.html#ga0573de65958b4fda3a0460ed417dafb8", null ],
    [ "sint8", "group___data_t.html#ga1a6408291ee3cfd0760a61ac64084154", null ],
    [ "tpfNmBspIsr", "group___data_t.html#gaf95259047872b09c538cb280f0466dcc", null ],
    [ "uint16", "group___data_t.html#ga05f6b0ae8f6a6e135b0e290c25fe0e4e", null ],
    [ "uint32", "group___data_t.html#ga4b435a49c74bb91f284f075e63416cb6", null ],
    [ "uint8", "group___data_t.html#gadde6aaee8457bee49c2a92621fe22b79", null ]
];