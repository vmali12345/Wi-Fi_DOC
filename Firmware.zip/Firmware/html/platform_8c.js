var platform_8c =
[
    [ "cleanup_platform", "platform_8c.html#a074e46b818accd4588b2fdf6dee7ec00", null ],
    [ "disable_caches", "platform_8c.html#a592da31a05d50149a2bc4ebe0fe52470", null ],
    [ "enable_caches", "platform_8c.html#a7a1d24821c9663bd8a1a9db242458765", null ],
    [ "init_platform", "platform_8c.html#afddcfa5cf23f52259c9da7f926a4af57", null ],
    [ "init_uart", "platform_8c.html#a7c8ab9435f095e55019fe880192c3537", null ]
];