var microchip__platform_8c =
[
    [ "MINIMUM_FW_MAJ", "microchip__platform_8c.html#a2f094f05564c0f305c4d3e37b0f9dded", null ],
    [ "MINIMUM_FW_MIN", "microchip__platform_8c.html#a8984d5ffd430dc0dd0a59b88107463cd", null ],
    [ "MINIMUM_FW_PATCH", "microchip__platform_8c.html#a922f0132bbde08948fae84184b654f97", null ],
    [ "TIMEOUT_VALUE", "microchip__platform_8c.html#a244ef94c7189373fc6959985376688ab", null ],
    [ "platform_cmd_cmpl_signal", "group__platform.html#gae8cc693b21f349d7c05a57b6a67a885d", null ],
    [ "platform_cmd_cmpl_wait", "group__platform.html#ga79e84be0acbee27c0bc43343c29652a7", null ],
    [ "platform_event_signal", "group__platform.html#gad6ce372bee4c440e77a7f8136cc42fc3", null ],
    [ "platform_event_wait", "group__platform.html#gaa7c8b49670cedd94c77d2d0b3dc114ea", null ],
    [ "platform_init", "group__platform.html#gaca518786bd8e2ba0001831df32371f0f", null ],
    [ "platform_interface_send", "group__platform.html#ga85fab698c0e53a2c08c060340ecbd2a4", null ],
    [ "platform_receive", "group__platform.html#ga4cc8b4ba9b50d70c8acbfabc16df6392", null ],
    [ "platform_set_timeout", "group__platform.html#ga8379963ac6b30bebad87343cfaba04d0", null ],
    [ "gu32Jiffies1ms", "microchip__platform_8c.html#aee1dc53a870c13e2f9c903e798c3bec9", null ]
];