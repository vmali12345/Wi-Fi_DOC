var http__entity_8h =
[
    [ "fileFormat", "group__sam0__httpc__group.html#ga76ccb82f4fe649df3933c92031a0369c", [
      [ "HTTP_FILE_FORMAT_NONE", "group__sam0__httpc__group.html#gga76ccb82f4fe649df3933c92031a0369ca6950dcb9f94369342ea732814abff78d", null ],
      [ "HTTP_FILE_FORMAT_FIT", "group__sam0__httpc__group.html#gga76ccb82f4fe649df3933c92031a0369cade165584de6d812dd72caac49267ecff", null ],
      [ "HTTP_FILE_FORMAT_TXT", "group__sam0__httpc__group.html#gga76ccb82f4fe649df3933c92031a0369ca7e89d246d2f675d60b8809b40656302e", null ]
    ] ]
];