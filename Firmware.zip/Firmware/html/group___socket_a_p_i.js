var group___socket_a_p_i =
[
    [ "accept", "group___socket_a_p_i.html#gac7c2f9f381cea0d52578825d7e563e8d", null ],
    [ "bind", "group___socket_a_p_i.html#gaa63dbc9b10866f101ae33ea3469645fd", null ],
    [ "close", "group___socket_a_p_i.html#ga0bd24b8455319e7c40b61a0835b25bb1", null ],
    [ "connect", "group___socket_a_p_i.html#ga0c6fead3153f45eb4c862590d2a64122", null ],
    [ "gethostbyname", "group___socket_a_p_i.html#ga9a396dd2a0d39e8421a5271ee1ea263e", null ],
    [ "getsockopt", "group___socket_a_p_i.html#ga96fb86e2f672c9cdcafb3585186fe549", null ],
    [ "listen", "group___socket_a_p_i.html#ga64a01a865709a621b249aaac455f9e8b", null ],
    [ "m2m_ping_req", "group___socket_a_p_i.html#ga7bd5251887bd43fc7cf8c4dc7edf32af", null ],
    [ "nmi_inet_addr", "group___socket_a_p_i.html#gafd9d1f56a7e508773730524f337bc8b8", null ],
    [ "recv", "group___socket_a_p_i.html#gafb96ba8adac96c7f6cc0d6c257418e17", null ],
    [ "recvfrom", "group___socket_a_p_i.html#ga1f9ae5629c787b74f46c43805987d1a1", null ],
    [ "registerSocketCallback", "group___socket_a_p_i.html#gaeb6be6be9f2cbaf61d3b27c8300b3677", null ],
    [ "send", "group___socket_a_p_i.html#ga926ec962609b596d9951199f52d02391", null ],
    [ "sendto", "group___socket_a_p_i.html#ga6a47ee942f7f547ec7f7cb921910444a", null ],
    [ "setsockopt", "group___socket_a_p_i.html#ga3843a64f3a423fb78e2fbc7ab5242c1c", null ],
    [ "socket", "group___socket_a_p_i.html#ga0686a847ab8065512bb230fc8845c2f1", null ],
    [ "socketDeinit", "group___socket_a_p_i.html#ga601505c91c3f21a9c0b4a51988357b4f", null ],
    [ "socketInit", "group___socket_a_p_i.html#ga5878b0f388e1d04b6f986f61a607ae4a", null ]
];