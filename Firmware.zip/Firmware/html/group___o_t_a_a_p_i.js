var group___o_t_a_a_p_i =
[
    [ "Functions", "group___o_t_a_f_u_n_c_t_i_o_n_s.html", "group___o_t_a_f_u_n_c_t_i_o_n_s" ],
    [ "Defines", "group___o_t_a_d_e_f_i_n_e.html", null ],
    [ "Enumeration/Typedefs", "group___o_t_a_t_y_p_e_d_e_f.html", "group___o_t_a_t_y_p_e_d_e_f" ]
];