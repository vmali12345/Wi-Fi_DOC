var nmspi_8h =
[
    [ "nm_spi_deinit", "nmspi_8h.html#a383dcdc2481fbedf9831753d074909d5", null ],
    [ "nm_spi_init", "nmspi_8h.html#ad60c342b7af8d5d8534e825620ecd2f6", null ],
    [ "nm_spi_read_block", "nmspi_8h.html#ac3964a8fd12bc450d1e9ba0c4c8ebe1f", null ],
    [ "nm_spi_read_reg", "nmspi_8h.html#a37c588aab608b441dbbaf508317e1ee3", null ],
    [ "nm_spi_read_reg_with_ret", "nmspi_8h.html#aae92c14d16f00b293e10a8a3a86f9095", null ],
    [ "nm_spi_write_block", "nmspi_8h.html#a49c8f196f4c41f481a06e359147484ca", null ],
    [ "nm_spi_write_reg", "nmspi_8h.html#a8e4e4efa9b987e6eed4c23b848248a32", null ]
];