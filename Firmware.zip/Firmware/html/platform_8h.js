var platform_8h =
[
    [ "cleanup_platform", "platform_8h.html#a074e46b818accd4588b2fdf6dee7ec00", null ],
    [ "init_platform", "platform_8h.html#afddcfa5cf23f52259c9da7f926a4af57", null ]
];