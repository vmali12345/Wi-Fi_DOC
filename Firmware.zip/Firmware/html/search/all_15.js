var searchData=
[
  ['va_5fnum_5fargs_0',['VA_NUM_ARGS',['../ble__utils_8h.html#aea7004aa2c18587dfc65211777fb0426',1,'ble_utils.h']]],
  ['va_5fnum_5fargs_5fimpl_1',['VA_NUM_ARGS_IMPL',['../ble__utils_8h.html#a3baadc3485dd8fcaca805631ba78c096',1,'ble_utils.h']]],
  ['value_2',['value',['../structatt__desired__type.html#aeef14454453499fb928cd0782e8274c8',1,'att_desired_type::value'],['../structatt__uuid__type.html#aeef14454453499fb928cd0782e8274c8',1,'att_uuid_type::value']]],
  ['value_5fhandle_3',['value_handle',['../structat__ble__characteristic__found__t.html#a784b76919ceb578bc00cc11238adb573',1,'at_ble_characteristic_found_t']]],
  ['value_5finit_5flen_4',['value_init_len',['../structat__ble__characteristic__t.html#a1bdee23606d013941b6df78daad85fcb',1,'at_ble_characteristic_t']]],
  ['value_5flen_5fmax_5',['VALUE_LEN_MAX',['../wifi__defines_8h.html#a00123bf30061132f1986d7a730283714',1,'wifi_defines.h']]],
  ['value_5fmax_5flen_6',['value_max_len',['../structat__ble__characteristic__t.html#aa72b9c8715f94b93b1eb97309917821f',1,'at_ble_characteristic_t']]],
  ['value_5fpermissions_7',['value_permissions',['../structat__ble__characteristic__t.html#a7973bc0ef3b3e4a8860f82b22e515ffb',1,'at_ble_characteristic_t']]],
  ['value_5fsize_8',['value_size',['../structatt__desired__type.html#a3958d142c677695fa42baeb461843f6f',1,'att_desired_type::value_size'],['../structatt__uuid__type.html#a193288446f6d66cea39fdf55a6fcc32d',1,'att_uuid_type::value_size']]],
  ['version_9',['VERSION',['../group___v_e_r_s_i_o_n.html',1,'']]],
  ['version_5ffield_5fvalid_10',['VERSION_FIELD_VALID',['../microchip__platform_8h.html#afb5752e203513c082c828bdaf4cbe5e9',1,'microchip_platform.h']]],
  ['volbase_11',['volbase',['../struct_f_a_t_f_s.html#a3e3472628262823af495681702709e8e',1,'FATFS']]]
];
