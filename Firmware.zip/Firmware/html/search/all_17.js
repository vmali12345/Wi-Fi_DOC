var searchData=
[
  ['year_0',['year',['../structat__ble__prf__date__time__t.html#a57ca98d8f6d4baf0fe41c583c7dcb0d5',1,'at_ble_prf_date_time_t']]]
];
