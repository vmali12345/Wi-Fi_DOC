var searchData=
[
  ['uart_5fdevice_5fid_0',['UART_DEVICE_ID',['../helloworld_8c.html#a0f4ff52ed3a5a46691f6a4d03988923d',1,'UART_DEVICE_ID:&#160;helloworld.c'],['../platform__config_8h.html#a0f4ff52ed3a5a46691f6a4d03988923d',1,'UART_DEVICE_ID:&#160;platform_config.h']]],
  ['udp_5fip_5fheader_5flength_1',['UDP_IP_HEADER_LENGTH',['../socket_8c.html#a3b1dc39f3493e3adcd67b833a7ef12e2',1,'socket.c']]],
  ['udp_5ftx_5fpacket_5foffset_2',['UDP_TX_PACKET_OFFSET',['../socket_8c.html#a8060494324fb1994ed86b8c0d5c4cfbd',1,'socket.c']]],
  ['unused_3',['UNUSED',['../compiler_8h.html#ada67c62b1c57e07efa04431bc40b9238',1,'compiler.h']]],
  ['unused1_4',['UNUSED1',['../ble__utils_8h.html#ab44e0eee663e5390cc20a1d7ddba6a5b',1,'ble_utils.h']]],
  ['unused2_5',['UNUSED2',['../ble__utils_8h.html#ae5f133855c03bd81edbfbc5f06333f73',1,'ble_utils.h']]],
  ['unused3_6',['UNUSED3',['../ble__utils_8h.html#a15a9e64f28614afb1c1ea5fc7e3b5032',1,'ble_utils.h']]],
  ['unused4_7',['UNUSED4',['../ble__utils_8h.html#a9ffd906c056dabca8fa6342ac578428c',1,'ble_utils.h']]],
  ['unused5_8',['UNUSED5',['../ble__utils_8h.html#aca8e64179bfee4ec00ce33189dcdad9f',1,'ble_utils.h']]],
  ['unused6_9',['UNUSED6',['../ble__utils_8h.html#aaf266ac9a7505e507284a59353dc2977',1,'ble_utils.h']]],
  ['unused7_10',['UNUSED7',['../ble__utils_8h.html#a78e1a7ca69e77f872e5e5d70e34cbde1',1,'ble_utils.h']]],
  ['unused8_11',['UNUSED8',['../ble__utils_8h.html#a9b08debd4ca3e1918b7942ed770afd18',1,'ble_utils.h']]],
  ['use_5fioctl_12',['USE_IOCTL',['../diskio_8h.html#ad10e6b9a90c685ea8fbe0a17d22cc0c7',1,'diskio.h']]],
  ['use_5fold_5fspi_5fsw_13',['USE_OLD_SPI_SW',['../nmspi_8c.html#ab1ccee75cf2ff9ef5a606819dd038713',1,'nmspi.c']]],
  ['use_5fwrite_14',['USE_WRITE',['../diskio_8h.html#a9a6bdc72dc58bacf4b496d95748cefac',1,'diskio.h']]]
];
