var searchData=
[
  ['peers_5finfo_0',['peers_info',['../structpeers__info.html',1,'']]],
  ['plf_5fparams_5ft_1',['plf_params_t',['../structplf__params__t.html',1,'']]]
];
