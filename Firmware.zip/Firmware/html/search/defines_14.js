var searchData=
[
  ['va_5fnum_5fargs_0',['VA_NUM_ARGS',['../ble__utils_8h.html#aea7004aa2c18587dfc65211777fb0426',1,'ble_utils.h']]],
  ['va_5fnum_5fargs_5fimpl_1',['VA_NUM_ARGS_IMPL',['../ble__utils_8h.html#a3baadc3485dd8fcaca805631ba78c096',1,'ble_utils.h']]],
  ['value_5flen_5fmax_2',['VALUE_LEN_MAX',['../wifi__defines_8h.html#a00123bf30061132f1986d7a730283714',1,'wifi_defines.h']]],
  ['version_5ffield_5fvalid_3',['VERSION_FIELD_VALID',['../microchip__platform_8h.html#afb5752e203513c082c828bdaf4cbe5e9',1,'microchip_platform.h']]]
];
