var m2m__hif_8h =
[
    [ "tstrHifHdr", "structtstr_hif_hdr.html", "structtstr_hif_hdr" ],
    [ "M2M_HIF_HDR_OFFSET", "m2m__hif_8h.html#a374fe954dffb43612aa5579e1bb340fe", null ],
    [ "M2M_HIF_MAX_PACKET_SIZE", "m2m__hif_8h.html#a3d3fd9d841573202e949bd931c5faf70", null ],
    [ "tpfHifCallBack", "m2m__hif_8h.html#ad14ffdb74f93ce725f5f1970accc7e97", null ],
    [ "hif_check_code", "m2m__hif_8h.html#aa83d95952c8f6842e2a00997204293b2", null ],
    [ "hif_check_compatibility", "m2m__hif_8h.html#ae5b148ac0f72b3e5696f8da620cac5ac", null ],
    [ "hif_chip_sleep", "m2m__hif_8h.html#a41d3f660265e122cbd7417ea8754e8dd", null ],
    [ "hif_chip_wake", "m2m__hif_8h.html#a88c8f023679d14d6866b80c9275db686", null ],
    [ "hif_deinit", "m2m__hif_8h.html#a297b5d8edbc7f34eedb4992bf20b16ab", null ],
    [ "hif_enable_access", "m2m__hif_8h.html#a6f20d52ff56402aa04521a203e4a22ed", null ],
    [ "hif_get_sleep_mode", "m2m__hif_8h.html#ad32fe2e6813b9ecfdd54d200e498468c", null ],
    [ "hif_handle_isr", "m2m__hif_8h.html#af66b8acfc8e66aae102b56ac84bca50d", null ],
    [ "hif_init", "m2m__hif_8h.html#acf3e2097e5a37d69e851250de3012de6", null ],
    [ "hif_receive", "m2m__hif_8h.html#a74395aadf04bddddf9c3cf9e55b9ec58", null ],
    [ "hif_register_cb", "m2m__hif_8h.html#a30fc4f91ec4d7859a4bf165152f1af7f", null ],
    [ "hif_send", "m2m__hif_8h.html#a13ba8ad11b2ac39516ca787386d16ce0", null ],
    [ "hif_set_sleep_mode", "m2m__hif_8h.html#aea14bdeaac412fb26e8a550bbd06ef91", null ],
    [ "hif_yield", "m2m__hif_8h.html#ab2a4423cf14c567ac2c485b7fdfffb7d", null ]
];