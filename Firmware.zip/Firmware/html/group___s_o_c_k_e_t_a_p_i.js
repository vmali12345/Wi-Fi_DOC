var group___s_o_c_k_e_t_a_p_i =
[
    [ "Defines", "group___s_o_c_k_e_t_d_e_f.html", "group___s_o_c_k_e_t_d_e_f" ]
];