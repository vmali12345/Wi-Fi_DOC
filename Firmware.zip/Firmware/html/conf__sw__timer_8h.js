var conf__sw__timer_8h =
[
    [ "CONF_SW_TIMER_CALLBACK_CHANNEL", "conf__sw__timer_8h.html#a28a3f9ddc7bfe74d5b36303c3ce0d2d4", null ],
    [ "CONF_SW_TIMER_COUNT", "conf__sw__timer_8h.html#ac27d87d6e83af6144d084f9bc683388d", null ]
];