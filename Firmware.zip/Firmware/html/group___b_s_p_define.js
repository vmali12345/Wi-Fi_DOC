var group___b_s_p_define =
[
    [ "Enumeration/Typedefs", "group___data_t.html", "group___data_t" ],
    [ "BSP_MIN", "group___b_s_p_define.html#ga53cd5682e7a3c1a3a9ec1baa8d5c29e2", null ],
    [ "CONST", "group___b_s_p_define.html#ga0c33b494a68ce28497e7ce8e5e95feff", null ],
    [ "NM_BSP_B_L_16", "group___b_s_p_define.html#ga22348273616354c0ac8a3de5ce4fb963", null ],
    [ "NM_BSP_B_L_32", "group___b_s_p_define.html#ga1a112ee31fdc083c5a196e5f22257608", null ],
    [ "NM_BSP_PRINTF", "group___b_s_p_define.html#ga749fd39c164b4d6f21f482cdf5a13e60", null ],
    [ "NM_DEBUG", "group___b_s_p_define.html#gaa1f419d763e03759beb40e1da011e7a8", null ],
    [ "NM_EDGE_INTERRUPT", "group___b_s_p_define.html#ga0f2b17da04fcba4b6079bd601aaed85e", null ],
    [ "NMI_API", "group___b_s_p_define.html#gaecc0323d771e41ef81a76b5f12783e22", null ],
    [ "NULL", "group___b_s_p_define.html#ga070d2ce7b6bb7e5c05602aa8c308d0c4", null ]
];