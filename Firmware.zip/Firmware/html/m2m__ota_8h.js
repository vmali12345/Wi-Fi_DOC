var m2m__ota_8h =
[
    [ "tpfOtaNotifCb", "group___o_t_a_t_y_p_e_d_e_f.html#ga794a38a7732c4c11ea0ca8081dbd6300", null ],
    [ "tpfOtaUpdateCb", "group___o_t_a_t_y_p_e_d_e_f.html#ga22bd7e1b61cfc92a1b6fe2340889efc5", null ],
    [ "m2m_ota_abort", "group___o_t_a_f_u_n_c_t_i_o_n_s.html#ga86ed96241dc57fecf4ab3067fe1d0a37", null ],
    [ "m2m_ota_init", "group___o_t_a_f_u_n_c_t_i_o_n_s.html#gacd2a1a8ffaccc3deb1970cf1ad41ceec", null ],
    [ "m2m_ota_notif_check_for_update", "group___o_t_a_f_u_n_c_t_i_o_n_s.html#ga522222363c6991cb078c38b06cfa6c80", null ],
    [ "m2m_ota_notif_sched", "group___o_t_a_f_u_n_c_t_i_o_n_s.html#ga5dab33fa39bd9aa510b482ccd4226f81", null ],
    [ "m2m_ota_notif_set_url", "group___o_t_a_f_u_n_c_t_i_o_n_s.html#ga98ab9f03996e6bf1cb21ba7259bb0058", null ],
    [ "m2m_ota_rollback", "group___o_t_a_f_u_n_c_t_i_o_n_s.html#gafdc5f0bb3d2a23b787816494ba1e5a48", null ],
    [ "m2m_ota_start_update", "group___o_t_a_f_u_n_c_t_i_o_n_s.html#gac50387eab16b3257f1c037942f2682fd", null ],
    [ "m2m_ota_switch_firmware", "group___o_t_a_f_u_n_c_t_i_o_n_s.html#ga464a45a53473152d5a78c578ae0edd8a", null ]
];