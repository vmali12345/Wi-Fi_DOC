var ll__if_8h =
[
    [ "bd_addr", "structbd__addr.html", "structbd__addr" ],
    [ "adv_data", "structadv__data.html", "structadv__data" ],
    [ "scan_rsp_data", "structscan__rsp__data.html", "structscan__rsp__data" ],
    [ "llm_le_set_adv_param_cmd", "structllm__le__set__adv__param__cmd.html", "structllm__le__set__adv__param__cmd" ],
    [ "llm_le_set_adv_data_cmd", "structllm__le__set__adv__data__cmd.html", "structllm__le__set__adv__data__cmd" ],
    [ "llm_le_set_scan_rsp_data_cmd", "structllm__le__set__scan__rsp__data__cmd.html", "structllm__le__set__scan__rsp__data__cmd" ],
    [ "llm_le_set_scan_param_cmd", "structllm__le__set__scan__param__cmd.html", "structllm__le__set__scan__param__cmd" ],
    [ "ADV_DATA_LEN", "ll__if_8h.html#ad878d0a8c7e2c7e98a25b9ed0d943cf5", null ],
    [ "BD_ADDR_LEN", "ll__if_8h.html#adc5356a86213ced2eebbc50b6251f6fe", null ],
    [ "L2C_MIN_LE_MTUSIG", "ll__if_8h.html#a86830851653ce62de71982a4640b7fa1", null ],
    [ "SCAN_RSP_DATA_LEN", "ll__if_8h.html#afbf5962c7c413efad35134dff0aebd74", null ]
];