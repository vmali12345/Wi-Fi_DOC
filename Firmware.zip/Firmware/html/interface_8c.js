var interface_8c =
[
    [ "NMI_BLE_COLLECTING_HDR", "interface_8c.html#ab12c4f932898d24e5b8cfca1c789d909", null ],
    [ "NMI_BLE_COLLECTING_PAYLOAD", "interface_8c.html#a0ee4cc8b88719ee09236328347552533", null ],
    [ "NMI_BLE_WAITING", "interface_8c.html#a3d414f88c732e33fa6fd100ff53e1381", null ],
    [ "interface_send", "interface_8c.html#ad935ea93311bc14670942294d91cb9ea", null ],
    [ "interface_send_wait", "interface_8c.html#ab909a21cca8d6a22a16359b53208da03", null ],
    [ "platform_interface_callback", "group__platform.html#gaeec7abf4ba0bab1b0e413b9a65080d7f", null ],
    [ "interface_send_msg", "interface_8c.html#af88eee0c7e7e75051474fb50bb8d35e3", null ]
];