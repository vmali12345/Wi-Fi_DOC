var http__client_8c =
[
    [ "DEFAULT_USER_AGENT", "http__client_8c.html#aa6407b49b77c8e44dc330223aa3be9a0", null ],
    [ "HTTP_CHUNKED_MAX_LENGTH", "http__client_8c.html#ac97911d2bd720c5e6dccf9d68510a0fc", null ],
    [ "MIN_SEND_BUFFER_SIZE", "http__client_8c.html#a4bcde3bba6878d54b69d77d9e4fcbe51", null ],
    [ "http_client_req_state", "http__client_8c.html#abef2fdf36fb4a3ac97d8770c790f636c", [
      [ "STATE_INIT", "http__client_8c.html#abef2fdf36fb4a3ac97d8770c790f636ca98d2a2153b4ae0445fa0b114d65b94d9", null ],
      [ "STATE_TRY_SOCK_CONNECT", "http__client_8c.html#abef2fdf36fb4a3ac97d8770c790f636ca4a9b2cb977ee0a5ed833407d31d8c5f1", null ],
      [ "STATE_SOCK_CONNECTED", "http__client_8c.html#abef2fdf36fb4a3ac97d8770c790f636caae850158d834441507e3ce4acbed6d17", null ],
      [ "STATE_REQ_SEND_HEADER", "http__client_8c.html#abef2fdf36fb4a3ac97d8770c790f636cad808ee1dc39dc66db5bb3be76c698b20", null ],
      [ "STATE_REQ_SEND_ENTITY", "http__client_8c.html#abef2fdf36fb4a3ac97d8770c790f636cad2e0e1383a94a8ee9d6eedc5db947275", null ]
    ] ],
    [ "http_client_resp_state", "http__client_8c.html#a2f350d7d556ac32828ef5acd173ed9d4", [
      [ "STATE_PARSE_HEADER", "http__client_8c.html#a2f350d7d556ac32828ef5acd173ed9d4abde9ff9318cadecfb4423e690dea01c6", null ],
      [ "STATE_PARSE_ENTITY", "http__client_8c.html#a2f350d7d556ac32828ef5acd173ed9d4ad71504286aac15aacae45100d70a7282", null ]
    ] ],
    [ "_http_client_clear_conn", "http__client_8c.html#a42cf1d59488a0755f2ce8e26c81cf2e6", null ],
    [ "_http_client_handle_entity", "http__client_8c.html#abd134f091806d73e9411c63caa6486cd", null ],
    [ "_http_client_handle_header", "http__client_8c.html#a121b911949a62974ee1e33d93268e012", null ],
    [ "_http_client_handle_response", "http__client_8c.html#a5e80112fb0144f7c5f7437aa8a062944", null ],
    [ "_http_client_move_buffer", "http__client_8c.html#a44a8479ea449d7dfa22f452fd5cacd36", null ],
    [ "_http_client_read_wait", "http__client_8c.html#a558ab0af24a10fd6fc0078887e2759cc", null ],
    [ "_http_client_recv_packet", "http__client_8c.html#a4e06ff4978422d649cc909d748f3cd3f", null ],
    [ "_http_client_recved_packet", "http__client_8c.html#a48acd4929a456dcf63b73d983c1991f5", null ],
    [ "_http_client_request", "http__client_8c.html#a6ab743dc88e01476ee6a83f0ebffa31f", null ],
    [ "_http_client_send_wait", "http__client_8c.html#a5735f1a88fc76bcbc3521a17d913b946", null ],
    [ "http_client_close", "group__sam0__httpc__group.html#ga3b780865c50a35872b9345a5b68f5827", null ],
    [ "http_client_deinit", "group__sam0__httpc__group.html#ga70ade0f3a852cf8ef85353d3924c4bbe", null ],
    [ "http_client_get_config_defaults", "group__sam0__httpc__group.html#gaee19421bcb97a63071929f2d7b236722", null ],
    [ "http_client_init", "group__sam0__httpc__group.html#ga378653b75c9a6c3aa0e4eece2a060f29", null ],
    [ "http_client_register_callback", "group__sam0__httpc__group.html#gac09af7517ba2954166ea3bdeffb94b39", null ],
    [ "http_client_send_request", "group__sam0__httpc__group.html#gabd66a129efd047b6b7d3f228237f991f", null ],
    [ "http_client_socket_event_handler", "group__sam0__httpc__group.html#ga3ac628e327d21a353ceaca0aa791ec51", null ],
    [ "http_client_socket_resolve_handler", "group__sam0__httpc__group.html#ga67a0805486cb8227ace452c91c2757f6", null ],
    [ "http_client_timer_callback", "http__client_8c.html#af119629dca761cf5fc573a177b9ce7ad", null ],
    [ "http_client_unregister_callback", "group__sam0__httpc__group.html#ga9e68a8961200d1421c3f5355db8097df", null ],
    [ "g_recv_pkg_cnt", "group__sam0__httpc__group.html#ga70ac76787683db9e4f40da1566f91f83", null ],
    [ "g_send_pkg_cnt", "group__sam0__httpc__group.html#gafcd0a32e95a87396a805ff98f0e2bc6e", null ]
];