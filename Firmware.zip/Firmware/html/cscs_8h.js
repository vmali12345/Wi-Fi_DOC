var cscs_8h =
[
    [ "csc_serv", "structcsc__serv.html", "structcsc__serv" ],
    [ "CSC_UUID_128_LEN", "cscs_8h.html#a976090b28af8a74f5af124f4d62f313d", null ],
    [ "csc_serv_t", "cscs_8h.html#a8c8e139b0677566af0e63e04f83be798", null ],
    [ "csc_serv_init", "cscs_8h.html#a1677aa7e95e3326d55ecf20bbe459cdd", null ],
    [ "csc_serv_send_data", "cscs_8h.html#a0f3d94bc89875442b1a93b71ed1b4004", null ]
];