var group___s_o_c_k_e_t_d_e_f =
[
    [ "TLS Cipher Suite IDs", "group___s_s_l_cipher_suite_i_d.html", "group___s_s_l_cipher_suite_i_d" ],
    [ "AF_INET", "group___s_o_c_k_e_t_d_e_f.html#ga9930604d0e32588eae76f43ca38e7826", null ],
    [ "HOSTNAME_MAX_SIZE", "group___s_o_c_k_e_t_d_e_f.html#ga0fa167ceba6d3196afb108eaf035ec16", null ],
    [ "IP_ADD_MEMBERSHIP", "group___s_o_c_k_e_t_d_e_f.html#ga924b1653500b7d3bf1bcef96a1a28431", null ],
    [ "IP_DROP_MEMBERSHIP", "group___s_o_c_k_e_t_d_e_f.html#gad9e530e8ee1d2a001717d40d3aa26618", null ],
    [ "MAX_SOCKET", "group___s_o_c_k_e_t_d_e_f.html#gac0ab6f439d003d912087974e24160b68", null ],
    [ "SO_SET_UDP_SEND_CALLBACK", "group___s_o_c_k_e_t_d_e_f.html#ga3b46804b627c155ea4643c77a9ba952f", null ],
    [ "SO_SSL_BYPASS_X509_VERIF", "group___s_o_c_k_e_t_d_e_f.html#gac950b8cd7811a0fe32c33c0c3786f49b", null ],
    [ "SO_SSL_ENABLE_CERTNAME_VALIDATION", "group___s_o_c_k_e_t_d_e_f.html#gafeb44bb4c7ef739f381049a059fc9fdd", null ],
    [ "SO_SSL_ENABLE_SESSION_CACHING", "group___s_o_c_k_e_t_d_e_f.html#ga6f200a7a38cf14580940040177979679", null ],
    [ "SO_SSL_ENABLE_SNI_VALIDATION", "group___s_o_c_k_e_t_d_e_f.html#ga6936062455061065e23d7e56500f0457", null ],
    [ "SO_SSL_SNI", "group___s_o_c_k_e_t_d_e_f.html#gab1e5de42bac42b2f7b73a849b6a9ed3e", null ],
    [ "SOCK_DGRAM", "group___s_o_c_k_e_t_d_e_f.html#ga4db8b9a846c67404db0b6f014f9a9fdf", null ],
    [ "SOCK_STREAM", "group___s_o_c_k_e_t_d_e_f.html#ga249394484f9410a2e3f8eba24657feb9", null ],
    [ "SOCKET_BUFFER_MAX_LENGTH", "group___s_o_c_k_e_t_d_e_f.html#ga347f2f3a1c6eb8a6ca8cd929e4704769", null ],
    [ "SOCKET_FLAGS_SSL", "group___s_o_c_k_e_t_d_e_f.html#gabba7069e08c6d3aa2f9029461d13498c", null ],
    [ "SOL_SOCKET", "group___s_o_c_k_e_t_d_e_f.html#ga92d045f6ee2f343d6b28830a9fec082e", null ],
    [ "SOL_SSL_SOCKET", "group___s_o_c_k_e_t_d_e_f.html#gaa56bd37cff4af1d0afb0004ad8de7e54", null ],
    [ "TCP_SOCK_MAX", "group___s_o_c_k_e_t_d_e_f.html#gab6c65ea312c8108924ada44302aa465f", null ],
    [ "UDP_SOCK_MAX", "group___s_o_c_k_e_t_d_e_f.html#gabbb22c156432dd303fe28b658ab8338d", null ]
];