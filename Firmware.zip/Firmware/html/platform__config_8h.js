var platform__config_8h =
[
    [ "STDOUT_IS_PS7_UART", "platform__config_8h.html#a6ff829e8266025a55a81fd12b9d329a9", null ],
    [ "UART_DEVICE_ID", "platform__config_8h.html#a0f4ff52ed3a5a46691f6a4d03988923d", null ]
];