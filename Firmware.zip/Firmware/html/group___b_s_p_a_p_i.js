var group___b_s_p_a_p_i =
[
    [ "nm_bsp_deinit", "group___b_s_p_a_p_i.html#ga21908c77ace36b999e63edf95751b1d0", null ],
    [ "nm_bsp_init", "group___b_s_p_a_p_i.html#ga91533a50cf3da832110a746b4a57789e", null ],
    [ "nm_bsp_interrupt_ctrl", "group___b_s_p_a_p_i.html#gad08e47a941e87d631200f990000323dc", null ],
    [ "nm_bsp_register_isr", "group___b_s_p_a_p_i.html#ga1b42af0f91da07772d2d5c871c9c3e62", null ],
    [ "nm_bsp_reset", "group___b_s_p_a_p_i.html#ga3e540428a9246a27c61999ecb7e13d05", null ],
    [ "nm_bsp_sleep", "group___b_s_p_a_p_i.html#gadbf38ddf0138d8e0a4e4720909a7b081", null ]
];