var gatt__client_8c =
[
    [ "at_ble_characteristic_discover_all", "group__gatt-client.html#ga219f9e312abd98aa41c5cce56fcc1dde", null ],
    [ "at_ble_characteristic_discover_by_uuid", "group__gatt-client.html#ga5bd8e51454cede0adcbf0b99eda34f0a", null ],
    [ "at_ble_characteristic_read", "group__gatt-client.html#gabae315596f9e0b85a5f4f1df0b5bf78d", null ],
    [ "at_ble_characteristic_read_by_uuid", "group__gatt-client.html#gad285cc2e31fbacc50d11a1c0ff6eb9e4", null ],
    [ "at_ble_characteristic_read_multible", "group__gatt-client.html#gac11c50f1e4c4e000c3ea813f2324dcae", null ],
    [ "at_ble_characteristic_reliable_write_cancel", "group__gatt-client.html#ga7d89d0a874b956a99356ca8aa7764ff8", null ],
    [ "at_ble_characteristic_reliable_write_execute", "group__gatt-client.html#ga9a3982336528fec5ec5c59f8937075cc", null ],
    [ "at_ble_characteristic_reliable_write_prepare", "group__gatt-client.html#gaeaad17e6de538db2f9db638a0fef0310", null ],
    [ "at_ble_characteristic_write", "group__gatt-client.html#ga68ed4c6179da222ba25a61487a7926b9", null ],
    [ "at_ble_descriptor_discover_all", "group__gatt-client.html#gabc3b59303cef6377ee364c7be4f27bb8", null ],
    [ "at_ble_exchange_mtu", "group__gatt-client.html#ga26fc3ac24ee5eb33237dfba027818238", null ],
    [ "at_ble_included_service_discover_all", "group__gatt-client.html#ga1937df46ff17c4490585d1ca540bc8fe", null ],
    [ "at_ble_primary_service_discover_all", "group__gatt-client.html#ga5bf7a23fc6f8b6fbc30de8ca5ed7d159", null ],
    [ "at_ble_primary_service_discover_by_uuid", "group__gatt-client.html#gadf352205d818cf47fc659824232bed9a", null ]
];