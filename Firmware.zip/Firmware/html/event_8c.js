var event_8c =
[
    [ "event", "structevent.html", "structevent" ],
    [ "EVENT_POOL_DEPTH", "event_8c.html#a1f19d8373e3dd4efcce2dd48d3ada580", null ],
    [ "at_ble_event_get", "group__gap.html#ga80845db83e539aacd58d93f598805c64", null ],
    [ "at_ble_event_user_defined_post", "group__gap.html#gadc0a033c5b84eee9ffd4c6c394be2520", null ],
    [ "event_init", "event_8c.html#a703aee6d18b09a8b0e7fa762e6024594", null ],
    [ "event_post", "event_8c.html#aaa292d94b56982e1bbf2584e1444ca94", null ],
    [ "special_events_handler", "event_8c.html#a02587a5d6716dd9ed4aa90caf2293fa6", null ],
    [ "watched_event", "event_8c.html#ae30df1d0463a0f7c3885f90d6799fd55", null ]
];