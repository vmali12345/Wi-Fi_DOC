var group___socket_error_code =
[
    [ "Enumeration/Typedefs", "group___socket_enums.html", "group___socket_enums" ],
    [ "SOCK_ERR_ADDR_ALREADY_IN_USE", "group___socket_error_code.html#ga9a5b7a6e19e83f7a6e833e17e7c64348", null ],
    [ "SOCK_ERR_ADDR_IS_REQUIRED", "group___socket_error_code.html#ga2f963801d32e6b0c2c88c36fb80c9574", null ],
    [ "SOCK_ERR_BUFFER_FULL", "group___socket_error_code.html#ga327a62f01f2b0d7b732bea32612acc42", null ],
    [ "SOCK_ERR_CONN_ABORTED", "group___socket_error_code.html#ga01823c4a616a2473abb8f3f8417c1df8", null ],
    [ "SOCK_ERR_INVALID", "group___socket_error_code.html#gaadbd3cd57b4ff7c25b6a9abc75cb37be", null ],
    [ "SOCK_ERR_INVALID_ADDRESS", "group___socket_error_code.html#ga0a9c7741ce999eb9232596590a812db5", null ],
    [ "SOCK_ERR_INVALID_ARG", "group___socket_error_code.html#ga4889a7ecf9dcfb3208d6f7c59b691d9d", null ],
    [ "SOCK_ERR_MAX_LISTEN_SOCK", "group___socket_error_code.html#ga5e89de97730fafeb35fe18e841b9c438", null ],
    [ "SOCK_ERR_MAX_TCP_SOCK", "group___socket_error_code.html#ga02b3df7adc7c06dd2fd82c14b4825a83", null ],
    [ "SOCK_ERR_MAX_UDP_SOCK", "group___socket_error_code.html#ga1263cb2444191b349489d26887047aad", null ],
    [ "SOCK_ERR_NO_ERROR", "group___socket_error_code.html#ga3d22d700a5ecefd5027c0f3c923ee095", null ],
    [ "SOCK_ERR_TIMEOUT", "group___socket_error_code.html#ga718ed6a0a949466e5dc13431e0a2f9a4", null ]
];