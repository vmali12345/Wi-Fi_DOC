var cscs_8c =
[
    [ "csc_serv_init", "cscs_8c.html#a1677aa7e95e3326d55ecf20bbe459cdd", null ],
    [ "csc_serv_send_data", "cscs_8c.html#a0f3d94bc89875442b1a93b71ed1b4004", null ],
    [ "csc_inst", "cscs_8c.html#a19c2136690118e5bfb5259a3c6a8fb22", null ]
];