var group__l2cap =
[
    [ "at_ble_l2cap_cid_register", "group__l2cap.html#gab55492885e1168f975dafc9e21c2ae64", null ],
    [ "at_ble_l2cap_cid_unregister", "group__l2cap.html#ga079e6394ee7c9f23ec4b4aa9420c3de9", null ],
    [ "at_ble_l2cap_tx", "group__l2cap.html#ga9c9ee0b44824db3fe4a274228aa7b99b", null ]
];