var group___v_e_r_s_i_o_n_a_p_i =
[
    [ "m2m_ota_get_firmware_version", "group___v_e_r_s_i_o_n_a_p_i.html#ga0ec5fe87254cd103b32d71090ea52842", null ],
    [ "m2m_wifi_check_ota_rb", "group___v_e_r_s_i_o_n_a_p_i.html#ga5c42f04575f441b2f3192ceabe9f269b", null ],
    [ "m2m_wifi_get_chipId", "group___v_e_r_s_i_o_n_a_p_i.html#gae9dff72aa449a42bf3b079e55f8307ad", null ],
    [ "m2m_wifi_get_firmware_version", "group___v_e_r_s_i_o_n_a_p_i.html#ga109a9d35c21d51e49633aae46be01342", null ]
];