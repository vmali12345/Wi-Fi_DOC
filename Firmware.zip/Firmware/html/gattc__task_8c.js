var gattc__task_8c =
[
    [ "gattc_complete_evt_handler", "gattc__task_8c.html#a090b9e0c35c9f1fb0f9d32aef2764eda", null ],
    [ "gattc_disc_char_desc_ind_parser", "gattc__task_8c.html#a213960f30a832719137d63e0c24ae1fb", null ],
    [ "gattc_disc_char_ind_parser", "gattc__task_8c.html#a4ef62d0207f341c8ce408d6782937eae", null ],
    [ "gattc_disc_cmd_handler", "gattc__task_8c.html#ab940e6d9fb3a33c0081062ed5030d12c", null ],
    [ "gattc_disc_svc_incl_ind_parser", "gattc__task_8c.html#af9cc41452dd0cedd52f55049e8143dc0", null ],
    [ "gattc_disc_svc_ind_parser", "gattc__task_8c.html#a46ae9f934db3d5a7d6fe12b210458ae5", null ],
    [ "gattc_event_ind_parser", "gattc__task_8c.html#a7994316ef8533762f67c2c29411883fd", null ],
    [ "gattc_execute_write_cmd_handler", "gattc__task_8c.html#a2f15ec9fdb977b98527c52bea822708e", null ],
    [ "gattc_mtu_cmd_handler", "gattc__task_8c.html#afde9010f436b797a5e61c11f65b13c5e", null ],
    [ "gattc_read_cmd_handler_by_uuid", "gattc__task_8c.html#a58b087c71eaa3237e78c3cc19bafb341", null ],
    [ "gattc_read_cmd_handler_multible", "gattc__task_8c.html#ab6ef2d7722eaf6f282bda35de6020693", null ],
    [ "gattc_read_cmd_handler_simple_read", "gattc__task_8c.html#a3a10b27e7d84e7f5c1da19950d76e036", null ],
    [ "gattc_read_ind_parser", "gattc__task_8c.html#a2c205f3a7ae822e7cac26adaaa58bfad", null ],
    [ "gattc_reg_to_peer_handler", "gattc__task_8c.html#a305087f5fcd7be1e2faa8a80c293ea63", null ],
    [ "gattc_send_evt_cmd_handler", "gattc__task_8c.html#a28c18a159f469c008a55692ab693e69f", null ],
    [ "gattc_svc_changed_notification_cmd_handler", "gattc__task_8c.html#acb3e82773a219f65071f56947eda7052", null ],
    [ "gattc_write_cmd_handler", "gattc__task_8c.html#a77f0de7da15f4ef357b0e6b956e61512", null ],
    [ "gattc_write_cmd_ind", "gattc__task_8c.html#aafe9fd1797244b58d112bfb49d674547", null ],
    [ "gattc_write_cmd_ind_handler", "gattc__task_8c.html#a1892246246881a40d8effba885dffde8", null ]
];