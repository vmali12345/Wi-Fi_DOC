var nmbus_8h =
[
    [ "nm_bus_iface_deinit", "nmbus_8h.html#a95773d3aefa29838b841bbfe7148b40b", null ],
    [ "nm_bus_iface_init", "nmbus_8h.html#ad272ee85c0dc9fbdc2a3c1a18a143554", null ],
    [ "nm_bus_iface_reconfigure", "nmbus_8h.html#ab501805e8c02565149e2374da370ec9c", null ],
    [ "nm_read_block", "nmbus_8h.html#af1e8ce2caa79fdd112216a9f36f103a0", null ],
    [ "nm_read_reg", "nmbus_8h.html#a40095d9f8d9cd502b40d93015c93af24", null ],
    [ "nm_read_reg_with_ret", "nmbus_8h.html#a475d273d8342f3f5c2a00e2887bf1b4f", null ],
    [ "nm_write_block", "nmbus_8h.html#afb924df7f944a8137cd51069512661cf", null ],
    [ "nm_write_reg", "nmbus_8h.html#a6a7d6b943cea86630575707ef80e09f9", null ]
];