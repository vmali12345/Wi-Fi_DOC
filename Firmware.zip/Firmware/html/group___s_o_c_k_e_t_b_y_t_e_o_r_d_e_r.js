var group___s_o_c_k_e_t_b_y_t_e_o_r_d_e_r =
[
    [ "Error Codes", "group___socket_error_code.html", "group___socket_error_code" ],
    [ "_htonl", "group___s_o_c_k_e_t_b_y_t_e_o_r_d_e_r.html#gad689dd88d15e087980c0b1ed71c29a42", null ],
    [ "_htons", "group___s_o_c_k_e_t_b_y_t_e_o_r_d_e_r.html#ga9778d254871cabab2da84409f88aa1f4", null ],
    [ "_ntohl", "group___s_o_c_k_e_t_b_y_t_e_o_r_d_e_r.html#gaa83c67ed3c2ad6e36148190268fab756", null ],
    [ "_ntohs", "group___s_o_c_k_e_t_b_y_t_e_o_r_d_e_r.html#gafc4d0340fa4b8cf5953420c282f85b9e", null ]
];