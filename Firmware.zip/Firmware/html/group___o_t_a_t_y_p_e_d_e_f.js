var group___o_t_a_t_y_p_e_d_e_f =
[
    [ "tpfOtaNotifCb", "group___o_t_a_t_y_p_e_d_e_f.html#ga794a38a7732c4c11ea0ca8081dbd6300", null ],
    [ "tpfOtaUpdateCb", "group___o_t_a_t_y_p_e_d_e_f.html#ga22bd7e1b61cfc92a1b6fe2340889efc5", null ],
    [ "tenuM2mOtaCmd", "group___o_t_a_t_y_p_e_d_e_f.html#ga0220996b43dbde1d7e6d6870fafd245c", [
      [ "M2M_OTA_REQ_NOTIF_SET_URL", "group___o_t_a_t_y_p_e_d_e_f.html#gga0220996b43dbde1d7e6d6870fafd245cafdfa30c169f4d954446ea79d040f0d52", null ],
      [ "M2M_OTA_REQ_NOTIF_CHECK_FOR_UPDATE", "group___o_t_a_t_y_p_e_d_e_f.html#gga0220996b43dbde1d7e6d6870fafd245ca5023370bd7256090aa28bd7b6a610da6", null ],
      [ "M2M_OTA_REQ_NOTIF_SCHED", "group___o_t_a_t_y_p_e_d_e_f.html#gga0220996b43dbde1d7e6d6870fafd245ca43354d348b11ce3006311208b4379de5", null ],
      [ "M2M_OTA_REQ_START_UPDATE", "group___o_t_a_t_y_p_e_d_e_f.html#gga0220996b43dbde1d7e6d6870fafd245cafaed6610ba423e8abf0568deae890cfb", null ],
      [ "M2M_OTA_REQ_SWITCH_FIRMWARE", "group___o_t_a_t_y_p_e_d_e_f.html#gga0220996b43dbde1d7e6d6870fafd245ca1230a122c8305cdc8f8ea4bab675838f", null ],
      [ "M2M_OTA_REQ_ROLLBACK", "group___o_t_a_t_y_p_e_d_e_f.html#gga0220996b43dbde1d7e6d6870fafd245cac5b9b5507958bc332401856af81cd748", null ],
      [ "M2M_OTA_REQ_ABORT", "group___o_t_a_t_y_p_e_d_e_f.html#gga0220996b43dbde1d7e6d6870fafd245cad1aa4fb98683f0b01b99f28f8d458f66", null ],
      [ "M2M_OTA_RESP_NOTIF_UPDATE_INFO", "group___o_t_a_t_y_p_e_d_e_f.html#gga0220996b43dbde1d7e6d6870fafd245caef014e15a25ebb50c3e57e7665d14aaf", null ],
      [ "M2M_OTA_RESP_UPDATE_STATUS", "group___o_t_a_t_y_p_e_d_e_f.html#gga0220996b43dbde1d7e6d6870fafd245ca631643e3dd7cd16ee951f2c353ab5e05", null ],
      [ "M2M_OTA_REQ_TEST", "group___o_t_a_t_y_p_e_d_e_f.html#gga0220996b43dbde1d7e6d6870fafd245caa72c63edf20a5bf7edcc78fdbcc09b7e", null ],
      [ "M2M_OTA_MAX_ALL", "group___o_t_a_t_y_p_e_d_e_f.html#gga0220996b43dbde1d7e6d6870fafd245cae4f51800647a28c5bbbd7060cd435106", null ]
    ] ],
    [ "tenuOtaUpdateStatus", "group___o_t_a_t_y_p_e_d_e_f.html#gab7006b9cb55eb414d0416d0513533eeb", [
      [ "OTA_STATUS_SUCSESS", "group___o_t_a_t_y_p_e_d_e_f.html#ggab7006b9cb55eb414d0416d0513533eeba5cdbd538a2ca5fead8e30f38a2e8f07b", null ],
      [ "OTA_STATUS_FAIL", "group___o_t_a_t_y_p_e_d_e_f.html#ggab7006b9cb55eb414d0416d0513533eeba54701f32696891a07b613bb157301c27", null ],
      [ "OTA_STATUS_INVAILD_ARG", "group___o_t_a_t_y_p_e_d_e_f.html#ggab7006b9cb55eb414d0416d0513533eeba1d75f438aa757d7e1bfbd5b7f3430c24", null ],
      [ "OTA_STATUS_INVAILD_RB_IMAGE", "group___o_t_a_t_y_p_e_d_e_f.html#ggab7006b9cb55eb414d0416d0513533eeba451e520e1c5fe5fe8f1d5e5033f138a2", null ],
      [ "OTA_STATUS_INVAILD_FLASH_SIZE", "group___o_t_a_t_y_p_e_d_e_f.html#ggab7006b9cb55eb414d0416d0513533eebae8e66cda4f30ac8da6d836f816849d29", null ],
      [ "OTA_STATUS_AlREADY_ENABLED", "group___o_t_a_t_y_p_e_d_e_f.html#ggab7006b9cb55eb414d0416d0513533eebadf89386bc196eecbc6391222b77333cf", null ],
      [ "OTA_STATUS_UPDATE_INPROGRESS", "group___o_t_a_t_y_p_e_d_e_f.html#ggab7006b9cb55eb414d0416d0513533eeba5143e975d62ec1b36c14e37f2553ad88", null ],
      [ "OTA_STATUS_IMAGE_VERIF_FAILED", "group___o_t_a_t_y_p_e_d_e_f.html#ggab7006b9cb55eb414d0416d0513533eeba3f3d7683fd8ee3d026cad78bfccf0457", null ],
      [ "OTA_STATUS_CONNECTION_ERROR", "group___o_t_a_t_y_p_e_d_e_f.html#ggab7006b9cb55eb414d0416d0513533eeba62b5257f5bfc53c725ee131ffde2b923", null ],
      [ "OTA_STATUS_SERVER_ERROR", "group___o_t_a_t_y_p_e_d_e_f.html#ggab7006b9cb55eb414d0416d0513533eebac8fdd2b0a2fa284faa697b379382f78a", null ],
      [ "OTA_STATUS_ABORTED", "group___o_t_a_t_y_p_e_d_e_f.html#ggab7006b9cb55eb414d0416d0513533eeba3b068b19f0fecbf86a381348fc389846", null ]
    ] ],
    [ "tenuOtaUpdateStatusType", "group___o_t_a_t_y_p_e_d_e_f.html#ga3e56744d263918b9e36016f78d823c3a", [
      [ "DL_STATUS", "group___o_t_a_t_y_p_e_d_e_f.html#gga3e56744d263918b9e36016f78d823c3aa9b634fb58a53969f9af8a89908e58c5e", null ],
      [ "SW_STATUS", "group___o_t_a_t_y_p_e_d_e_f.html#gga3e56744d263918b9e36016f78d823c3aa2f1dabb326d861eadb5a5cd1b41962ff", null ],
      [ "RB_STATUS", "group___o_t_a_t_y_p_e_d_e_f.html#gga3e56744d263918b9e36016f78d823c3aad9b2f16f8c41c4108806a4c78dea422c", null ],
      [ "AB_STATUS", "group___o_t_a_t_y_p_e_d_e_f.html#gga3e56744d263918b9e36016f78d823c3aa0b4e411fb407bc62bf6b94175158862c", null ]
    ] ]
];