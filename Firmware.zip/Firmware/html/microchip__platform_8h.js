var microchip__platform_8h =
[
    [ "plf_params_t", "structplf__params__t.html", "structplf__params__t" ],
    [ "fw_version", "structplf__params__t_1_1fw__version.html", "structplf__params__t_1_1fw__version" ],
    [ "VERSION_FIELD_VALID", "microchip__platform_8h.html#afb5752e203513c082c828bdaf4cbe5e9", null ],
    [ "platform_cmd_cmpl_signal", "group__platform.html#gae8cc693b21f349d7c05a57b6a67a885d", null ],
    [ "platform_cmd_cmpl_wait", "group__platform.html#ga79e84be0acbee27c0bc43343c29652a7", null ],
    [ "platform_event_signal", "group__platform.html#gad6ce372bee4c440e77a7f8136cc42fc3", null ],
    [ "platform_event_wait", "group__platform.html#gaa7c8b49670cedd94c77d2d0b3dc114ea", null ],
    [ "platform_init", "group__platform.html#gaca518786bd8e2ba0001831df32371f0f", null ],
    [ "platform_interface_callback", "group__platform.html#gaeec7abf4ba0bab1b0e413b9a65080d7f", null ],
    [ "platform_interface_send", "group__platform.html#ga85fab698c0e53a2c08c060340ecbd2a4", null ],
    [ "platform_receive", "group__platform.html#ga4cc8b4ba9b50d70c8acbfabc16df6392", null ],
    [ "platform_set_timeout", "group__platform.html#ga8379963ac6b30bebad87343cfaba04d0", null ]
];